﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabricadorDeArepas
{
    public abstract class Arepa // no se puede usar "new" en una clase abstracta, no se intancia pues es astracta
    {
        //Los atributos
        protected int numeroMolino, diasCaducidad;
        
        //En este caso se instacio aca los datos pero si no se pone aca se tendria que poner en los hijos 
        public Arepa()
        {
            numeroMolino = 0;
            diasCaducidad = 0;
        }
        public Arepa(int numeroMolino, int diasCaducidad)
        {
            this.numeroMolino = numeroMolino;
            this.diasCaducidad = diasCaducidad;
        }
        //-----------------------------------------------------------------------------------------------------
        //Propiedades para los atributos

        public int NumeroMolino
        {
            get { return numeroMolino; }
            set { numeroMolino = value; }
        }
        public int DiasDeCaducidad
        {
            get { return diasCaducidad; }
            set { diasCaducidad = value; }
        }
        //-----------------------------------------------------------------------------------------------------


        //Metodos get/set 
        public int GetNumeroMolino()
        {
            return numeroMolino;
        }
        public void SetNumeroMolino(int numeroMolino)
        {
            this.numeroMolino = numeroMolino;
        }
        public abstract string ObtieneInformacion();

    }
}
