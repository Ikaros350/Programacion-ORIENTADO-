﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabricadorDeArepas
{
    class ArepaCongelada : Arepa, ICongelable
    {
        private int diasMaximosCongelado;
       
        //constructor de clase

        public ArepaCongelada() : base() 
        {
            diasMaximosCongelado = 0;
        }
        public ArepaCongelada(int numeroMolino, 
            int diasCaducidad, 
            int diasMaximosCongelado) : base(diasCaducidad, numeroMolino) //Toma dos de estos y se los manda al padre "Arepa"
        {
            //No se ponen los otro pues con la "base" se inicializaron
            this.diasMaximosCongelado = diasMaximosCongelado;
        }
        //Propiedad para los atributos
        public int DiasMaximosCongelado
        {
            get { return diasMaximosCongelado; }
            set { diasMaximosCongelado = value; }
        }

        //Aca se resuelven los errores "Las deudas del padre al hijo"
        public string InfoCongelacion()
        {
            string resultado = "Dias maximos de congelacion: " +
                diasMaximosCongelado + Environment.NewLine; //Equivalente a salto de linea
            return resultado;
        }
        public override string ObtieneInformacion()
        {
            string resultado = "Esta arepa fue congelada. "+Environment.NewLine + 
                "La masa salio del molino " +numeroMolino +Environment.NewLine + 
                "Tiene "+ diasCaducidad + "dias de caducidad" +Environment.NewLine + 
                InfoCongelacion();
            return resultado;
        }
    }
}
