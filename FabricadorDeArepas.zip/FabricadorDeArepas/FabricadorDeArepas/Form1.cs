﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FabricadorDeArepas
{
    public partial class Form1 : Form
    {
        private CreadorArepas elCreador;
        public Form1()
        {
            InitializeComponent();
            elCreador = new CreadorArepas();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            elCreador.InicializarArepas();

            // aqui visualizamos su resultado

            txtAsadas.Text = elCreador.TotalAsadas.ToString();
            txtCogeladas.Text = elCreador.TotalCongeladas.ToString();
            txtProcesadas.Text = elCreador.TotalProcesadas.ToString();
            txtResultados.Text = elCreador.ObtieneTotalInfo();
        }
    }
}
