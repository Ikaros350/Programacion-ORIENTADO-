﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabricadorDeArepas
{
    class ArepaAsada : Arepa, IAsable
    {
        private int temperaturaCoccion;

        //constructor de clase

        public ArepaAsada() : base()
        {
            temperaturaCoccion = 0;
        }

        public ArepaAsada(int numeroMolino, 
            int diasCaducidad, 
            int temperaturaCoccion) : base(diasCaducidad, numeroMolino) //Toma dos de estos y se los manda al padre "Arepa"
        {
            //No se ponen los otro pues con la "base" se inicializaron
            this.temperaturaCoccion = temperaturaCoccion;
        }
        //Propiedades del atributo
        public int TemperaturaCoccion
        {
            get { return temperaturaCoccion; }
            set { temperaturaCoccion = value; }
        }

        //Aca se resuelven los errores "Las deudas del padre al hijo"
        public string InfoCoccion()
        {
            string resultado = "Temperatura maxima de Coccion: "+
                temperaturaCoccion + Environment.NewLine; //Equivalente a salto de linea
            return resultado;
        }
        public override string ObtieneInformacion()
        {
            string resultado = "Esta arepa fue asada. "+Environment.NewLine + 
                "La masa salio del molino " + numeroMolino + Environment.NewLine +
                "Tiene " + diasCaducidad + "dias de caducidad" + Environment.NewLine + 
                InfoCoccion();
            return resultado;
        }
    }
}
