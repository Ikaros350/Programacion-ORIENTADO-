﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabricadorDeArepas
{
    class ArepaProcesada : Arepa, ICongelable, IAsable
    {
        //Los atributos 
        private int diasMaximosCongelado, temperaturaCoccion;

        public ArepaProcesada() : base()
        {
            diasMaximosCongelado = 0;
            temperaturaCoccion = 0;
        }

        public ArepaProcesada(int diasMaximosCongelado,
            int temperaturaCoccion,
            int numeroMolino,
            int diasCaducidad) : base(numeroMolino, diasCaducidad)
        {
            this.temperaturaCoccion = temperaturaCoccion;
            this.diasMaximosCongelado = diasMaximosCongelado;
        }

        public int DiasMaximosCongelado
        {
            get { return diasMaximosCongelado; }
            set { diasMaximosCongelado = value; }
        }
        public int TemperaturaCoccion
        {
            get { return temperaturaCoccion; }
            set { temperaturaCoccion = value; }
        }

        public string InfoCoccion()
        {

            string resultado = "Temperatura de coccion en proceso: " +
                temperaturaCoccion + Environment.NewLine; //Equivalente a salto de linea;
            return resultado;
        }
        public string InfoCongelacion()
        {

            string resultado = "Dias maximos congelada: "+ 
                diasMaximosCongelado + Environment.NewLine; //Equivalente a salto de linea;
            return resultado;
        }
        public override string ObtieneInformacion()
        {
            string resultado = "Esta arepa fue procesada. " + Environment.NewLine +
                "La masa salio del molino " + numeroMolino + Environment.NewLine +
                "Tiene " + diasCaducidad + "dias de caducidad" + Environment.NewLine +
                InfoCongelacion() + InfoCoccion();
            return resultado;
        }
    }
}
